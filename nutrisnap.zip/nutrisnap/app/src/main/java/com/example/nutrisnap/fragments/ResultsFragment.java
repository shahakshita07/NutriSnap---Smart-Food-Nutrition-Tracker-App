package com.example.nutrisnap.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.nutrisnap.FoodItem;
import com.example.nutrisnap.R;
import com.example.nutrisnap.SharedViewModel;

import java.util.List;

public class ResultsFragment extends Fragment {

    private TextView tvCalories, tvProtein, tvCarbs, tvFats, tvGoalLeft, tvGoalCompleted, tvFoodName;
    private ProgressBar progressBar;
    private SharedViewModel sharedViewModel;

    private static final int TOTAL_GOAL = 2000; // daily calorie goal

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_results_fragment, container, false);

        tvCalories = view.findViewById(R.id.tvCalories);
        tvProtein = view.findViewById(R.id.tvProtein);
        tvCarbs = view.findViewById(R.id.tvCarbs);
        tvFats = view.findViewById(R.id.tvFats);
        tvGoalLeft = view.findViewById(R.id.tvGoalLeft);
        tvGoalCompleted = view.findViewById(R.id.tvGoalCompleted);
        progressBar = view.findViewById(R.id.progressBar);
        tvFoodName = view.findViewById(R.id.tvFoodName); // Add in XML for showing food name

        // Get Shared ViewModel
        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);

        // Observe LiveData for food items
        sharedViewModel.getFoodList().observe(getViewLifecycleOwner(), foodItems -> {
            if (foodItems != null && !foodItems.isEmpty()) {
                // Display the last added food item (latest scanned one)
                FoodItem latestFood = foodItems.get(foodItems.size() - 1);
                setNutritionData(latestFood);
            }
        });

        return view;
    }

    // This makes the page dynamic
    private void setNutritionData(FoodItem foodItem) {
        if (foodItem == null) return;

        double calories = foodItem.getCalories();
        double protein = foodItem.getProtein();
        double carbs = foodItem.getCarbs();
        double fats = foodItem.getFat();

        tvFoodName.setText("Food: " + foodItem.getName());
        tvCalories.setText("Calories: " + String.format("%.1f kcal", calories));
        tvProtein.setText("Protein: " + String.format("%.1f g", protein));
        tvCarbs.setText("Carbs: " + String.format("%.1f g", carbs));
        tvFats.setText("Fats: " + String.format("%.1f g", fats));

        int goalLeft = (int) (TOTAL_GOAL - calories);
        tvGoalLeft.setText("Goal Left: " + goalLeft + " kcal");
        tvGoalCompleted.setText("Goal Completed: " + (int) calories + " kcal");

        int progress = (int) ((calories * 100.0f) / TOTAL_GOAL);
        progressBar.setProgress(progress);
    }
}
