package com.example.nutrisnap;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {

    private EditText regEmailEt, regPasswordEt, regConfirmEt;
    private Button regCreateBtn, regBackToLogin;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        auth = FirebaseAuth.getInstance();

        regEmailEt = findViewById(R.id.etEmailReg);
        regPasswordEt = findViewById(R.id.etPasswordReg);
        regConfirmEt = findViewById(R.id.etConfirmReg);
        regCreateBtn = findViewById(R.id.btnCreateAccount);
        regBackToLogin = findViewById(R.id.btnBackToLogin);

        regCreateBtn.setOnClickListener(view -> registerUser());
        regBackToLogin.setOnClickListener(v -> {
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            finish();
        });
    }

    private void registerUser() {
        String email = regEmailEt.getText().toString().trim();
        String pass = regPasswordEt.getText().toString().trim();
        String confirm = regConfirmEt.getText().toString().trim();

        if (email.isEmpty() || pass.isEmpty() || confirm.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            regEmailEt.setError("Invalid email format");
            regEmailEt.requestFocus();
            return;
        }

        if (pass.length() < 6) {
            regPasswordEt.setError("Password must be at least 6 characters");
            regPasswordEt.requestFocus();
            return;
        }

        if (!pass.equals(confirm)) {
            regConfirmEt.setError("Passwords do not match");
            regConfirmEt.requestFocus();
            return;
        }

        regCreateBtn.setEnabled(false);

        auth.createUserWithEmailAndPassword(email, pass)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        regCreateBtn.setEnabled(true);
                        if (task.isSuccessful()) {
                            Toast.makeText(RegisterActivity.this, "Account Created Successfully!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                            finish();
                        } else {
                            String error = task.getException() != null ? task.getException().getMessage() : "Failed to Register";
                            Toast.makeText(RegisterActivity.this, "Error: " + error, Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }
}
