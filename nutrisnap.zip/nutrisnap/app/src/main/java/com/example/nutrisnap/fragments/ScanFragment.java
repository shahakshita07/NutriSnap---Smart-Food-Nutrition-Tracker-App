package com.example.nutrisnap.fragments;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.nutrisnap.FoodItem;
import com.example.nutrisnap.R;
import com.example.nutrisnap.SharedViewModel;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ScanFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 1;
    private static final String API_KEY = "0f045bb668aa4527a54ae19ed63e2763";

    private ImageView previewImage;
    private EditText editFoodName, editQuantity, editCalories, editProtein, editCarbs, editFat;
    private Button btnUploadImage, btnAddFood, btnFetchNutrients;
    private Uri selectedImageUri;
    private SharedViewModel sharedViewModel;
    private boolean autoFetchTriggered = false;
    private ProgressDialog progressDialog;

    private DatabaseReference databaseRef; // ✅ Firebase reference

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_scan_fragment, container, false);

        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);
        databaseRef = FirebaseDatabase.getInstance().getReference("foods"); // ✅ Root reference

        linkUI(view);

        btnUploadImage.setOnClickListener(v -> openImagePicker());
        btnFetchNutrients.setOnClickListener(v -> {
            String food = editFoodName.getText().toString().trim();
            String qty = editQuantity.getText().toString().trim();
            if (!food.isEmpty()) fetchNutrientsFromAPI(food + " " + qty);
            else Toast.makeText(getContext(), "Please enter food name", Toast.LENGTH_SHORT).show();
        });

        TextWatcher autoFetchWatcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                String food = editFoodName.getText().toString().trim();
                String qty = editQuantity.getText().toString().trim();
                if (!food.isEmpty() && !qty.isEmpty() && !autoFetchTriggered) {
                    autoFetchTriggered = true;
                    fetchNutrientsFromAPI(food + " " + qty);
                }
            }
            @Override public void afterTextChanged(Editable s) {}
        };

        editFoodName.addTextChangedListener(autoFetchWatcher);
        editQuantity.addTextChangedListener(autoFetchWatcher);
        btnAddFood.setOnClickListener(v -> addFoodToDashboard());

        return view;
    }

    private void linkUI(View view) {
        previewImage = view.findViewById(R.id.previewImage);
        btnUploadImage = view.findViewById(R.id.btnUploadImage);
        btnAddFood = view.findViewById(R.id.btnAddFood);
        btnFetchNutrients = view.findViewById(R.id.btnFetchNutrients);
        editFoodName = view.findViewById(R.id.editFoodName);
        editQuantity = view.findViewById(R.id.editQuantity);
        editCalories = view.findViewById(R.id.editCalories);
        editProtein = view.findViewById(R.id.editProtein);
        editCarbs = view.findViewById(R.id.editCarbs);
        editFat = view.findViewById(R.id.editFat);
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Food Image"), PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            previewImage.setImageURI(selectedImageUri);
        }
    }

    private void fetchNutrientsFromAPI(String query) {
        progressDialog = ProgressDialog.show(getContext(), "Fetching Nutrients", "Please wait...", true);

        new Thread(() -> {
            try {
                String urlString = "https://api.spoonacular.com/recipes/guessNutrition?title=" +
                        query.replace(" ", "%20") + "&apiKey=" + API_KEY;

                HttpURLConnection connection = (HttpURLConnection) new URL(urlString).openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) response.append(line);
                reader.close();

                requireActivity().runOnUiThread(() -> {
                    progressDialog.dismiss();
                    parseNutritionResponse(response.toString());
                    autoFetchTriggered = false;
                });
            } catch (Exception e) {
                e.printStackTrace();
                requireActivity().runOnUiThread(() -> {
                    progressDialog.dismiss();
                    autoFetchTriggered = false;
                    Toast.makeText(getContext(), "Error fetching data ⚠️", Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    private void parseNutritionResponse(String result) {
        try {
            JSONObject json = new JSONObject(result);

            JSONObject caloriesObj = json.getJSONObject("calories");
            JSONObject proteinObj = json.getJSONObject("protein");
            JSONObject fatObj = json.getJSONObject("fat");
            JSONObject carbsObj = json.getJSONObject("carbs");

            double calories = caloriesObj.getDouble("value");
            double protein = proteinObj.getDouble("value");
            double fat = fatObj.getDouble("value");
            double carbs = carbsObj.getDouble("value");

            editCalories.setText(String.valueOf(Math.round(calories)));
            editProtein.setText(String.format("%.1f", protein));
            editCarbs.setText(String.format("%.1f", carbs));
            editFat.setText(String.format("%.1f", fat));

            String foodName = editFoodName.getText().toString().trim();
            sharedViewModel.setNutritionData(foodName, calories, protein, carbs, fat);

            Toast.makeText(getContext(), "Nutrients fetched ✅", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Error parsing data ⚠️", Toast.LENGTH_SHORT).show();
        }
    }

    private void addFoodToDashboard() {
        String name = editFoodName.getText().toString().trim();
        String quantity = editQuantity.getText().toString().trim();
        String calStr = editCalories.getText().toString().trim();
        String protStr = editProtein.getText().toString().trim();
        String carbStr = editCarbs.getText().toString().trim();
        String fatStr = editFat.getText().toString().trim();

        if (name.isEmpty() || calStr.isEmpty()) {
            Toast.makeText(getContext(), "Please fill all fields or fetch nutrients", Toast.LENGTH_SHORT).show();
            return;
        }

        double calories = Double.parseDouble(calStr);
        double protein = protStr.isEmpty() ? 0 : Double.parseDouble(protStr);
        double carbs = carbStr.isEmpty() ? 0 : Double.parseDouble(carbStr);
        double fat = fatStr.isEmpty() ? 0 : Double.parseDouble(fatStr);

        FoodItem newFood = new FoodItem(name, quantity, calories, protein, carbs, fat);
        sharedViewModel.addFood(newFood);
        sharedViewModel.setNutritionData(name, calories, protein, carbs, fat);

        // ✅ Save to Firebase Realtime Database
        databaseRef.push().setValue(newFood).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(getContext(), "Saved to Firebase ✅", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "Failed to save in Firebase ❌", Toast.LENGTH_SHORT).show();
            }
        });

        Toast.makeText(getContext(), "Food added to Dashboard ✅", Toast.LENGTH_SHORT).show();
        resetFields();
    }

    private void resetFields() {
        editFoodName.setText("");
        editQuantity.setText("");
        editCalories.setText("");
        editProtein.setText("");
        editCarbs.setText("");
        editFat.setText("");
        previewImage.setImageResource(R.drawable.food_placeholder);
        selectedImageUri = null;
        autoFetchTriggered = false;
    }
}