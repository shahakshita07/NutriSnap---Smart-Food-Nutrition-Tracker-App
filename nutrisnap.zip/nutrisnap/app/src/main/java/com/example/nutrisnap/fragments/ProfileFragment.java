package com.example.nutrisnap.fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.nutrisnap.LoginActivity;
import com.example.nutrisnap.R;
import com.google.firebase.auth.FirebaseAuth;

public class ProfileFragment extends Fragment {

    private EditText editUsername, editHeight, editWeight;
    private TextView txtBMI, txtGoal;
    private Button btnSave, btnCalculateBMI, btnLogout, btnEditGoal;

    private SharedPreferences prefs;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_profile_fragment, container, false);

        // Initialize UI
        editUsername = view.findViewById(R.id.editUsername);
        editHeight = view.findViewById(R.id.editHeight);
        editWeight = view.findViewById(R.id.editWeight);
        txtBMI = view.findViewById(R.id.txtBMI);
        txtGoal = view.findViewById(R.id.txtGoal);
        btnSave = view.findViewById(R.id.btnSave);
        btnCalculateBMI = view.findViewById(R.id.btnCalculateBMI);
        btnLogout = view.findViewById(R.id.btnLogout);
        btnEditGoal = view.findViewById(R.id.btnEditGoal);

        // Initialize SharedPreferences
        prefs = requireContext().getSharedPreferences("UserProfile", Context.MODE_PRIVATE);

        // Load saved profile data
        loadProfile();

        // Save Profile Button
        btnSave.setOnClickListener(v -> saveProfile());

        // Calculate BMI Button
        btnCalculateBMI.setOnClickListener(v -> calculateBMI());

        // Edit Goal Button (Dialog)
        btnEditGoal.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle("Edit Goal");

            final EditText input = new EditText(getContext());
            input.setHint("Enter new goal (e.g., Lose weight)");
            builder.setView(input);

            builder.setPositiveButton("Save", (dialog, which) -> {
                String newGoal = input.getText().toString().trim();
                if (!newGoal.isEmpty()) {
                    txtGoal.setText(newGoal);
                    prefs.edit().putString("goal", newGoal).apply();
                    Toast.makeText(getContext(), "Goal updated!", Toast.LENGTH_SHORT).show();
                }
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
            builder.show();
        });

        // Logout Button
        btnLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });

        return view;
    }

    /** Save user profile details **/
    private void saveProfile() {
        String name = editUsername.getText().toString().trim();
        String height = editHeight.getText().toString().trim();
        String weight = editWeight.getText().toString().trim();
        String goal = txtGoal.getText().toString().trim();

        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("username", name);
        editor.putString("height", height);
        editor.putString("weight", weight);
        editor.putString("goal", goal);
        editor.apply();

        Toast.makeText(getContext(), "Profile Saved Successfully!", Toast.LENGTH_SHORT).show();
    }

    /** Load saved user data **/
    private void loadProfile() {
        String name = prefs.getString("username", "");
        String goal = prefs.getString("goal", "No goal set");
        String height = prefs.getString("height", "");
        String weight = prefs.getString("weight", "");

        editUsername.setText(name);
        txtGoal.setText(goal);
        editHeight.setText(height);
        editWeight.setText(weight);
    }

    /** BMI Calculation **/
    private void calculateBMI() {
        try {
            float height = Float.parseFloat(editHeight.getText().toString());
            float weight = Float.parseFloat(editWeight.getText().toString());

            float bmi = weight / ((height / 100) * (height / 100));
            String category;

            if (bmi < 18.5) {
                category = "Underweight";
            } else if (bmi < 24.9) {
                category = "Normal";
            } else if (bmi < 29.9) {
                category = "Overweight";
            } else {
                category = "Obese";
            }

            txtBMI.setText(String.format("BMI: %.2f\n%s", bmi, category));

        } catch (Exception e) {
            Toast.makeText(getContext(), "Please enter valid height and weight", Toast.LENGTH_SHORT).show();
        }
    }
}
