package com.example.nutrisnap;

import com.google.gson.annotations.SerializedName;

public class FoodItem {

    @SerializedName("name")
    private String name;

    @SerializedName("quantity")
    private String quantity;

    @SerializedName("calories")
    private double calories;

    @SerializedName("protein")
    private double protein;

    @SerializedName("carbs")
    private double carbs;

    @SerializedName("fat")
    private double fat;

    // Default constructor (needed for Firebase/Retrofit)
    public FoodItem() {}

    // Main constructor
    public FoodItem(String name, String quantity, double calories, double protein, double carbs, double fat) {
        this.name = name;
        this.quantity = quantity;
        this.calories = calories;
        this.protein = protein;
        this.carbs = carbs;
        this.fat = fat;
    }

    // Getters
    public String getName() { return name; }
    public String getQuantity() { return quantity; }
    public double getCalories() { return calories; }
    public double getProtein() { return protein; }
    public double getCarbs() { return carbs; }
    public double getFat() { return fat; }

    // Setters
    public void setName(String name) { this.name = name; }
    public void setQuantity(String quantity) { this.quantity = quantity; }
    public void setCalories(double calories) { this.calories = calories; }
    public void setProtein(double protein) { this.protein = protein; }
    public void setCarbs(double carbs) { this.carbs = carbs; }
    public void setFat(double fat) { this.fat = fat; }

    // Helper for setting nutrient data from API
    public void setNutritionData(double calories, double protein, double carbs, double fat) {
        this.calories = calories;
        this.protein = protein;
        this.carbs = carbs;
        this.fat = fat;
    }

    // Optional: easy-to-read debug log
    @Override
    public String toString() {
        return "FoodItem{" +
                "name='" + name + '\'' +
                ", quantity='" + quantity + '\'' +
                ", calories=" + calories +
                ", protein=" + protein +
                ", carbs=" + carbs +
                ", fat=" + fat +
                '}';
    }
}
