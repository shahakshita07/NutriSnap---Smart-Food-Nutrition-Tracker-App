package com.example.nutrisnap;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class InputActivity extends AppCompatActivity {

    private EditText etFoodName, etQuantity;
    private Button btnAnalyze, btnUploadImage;
    private ImageView ivPreview;

    private static final String API_URL = "https://api.calorieninjas.com/v1/nutrition?query=";
    private static final String API_KEY = "kB2p7mZ4N+TxNZKsDimwnQ==pyVur9h5XVHs1gV5";

    private FirebaseAuth auth;
    private DatabaseReference dbRef;
    private StorageReference storageRef;

    private Uri selectedImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        etFoodName = findViewById(R.id.etFoodName);
        etQuantity = findViewById(R.id.etQuantity);
        btnAnalyze = findViewById(R.id.btnAnalyze);
        btnUploadImage = findViewById(R.id.btnUploadImage);
        ivPreview = findViewById(R.id.ivPreview);

        auth = FirebaseAuth.getInstance();
        dbRef = FirebaseDatabase.getInstance().getReference("users");
        storageRef = FirebaseStorage.getInstance().getReference("food_images");

        // Launch gallery picker
        ActivityResultLauncher<String> galleryLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        selectedImageUri = uri;
                        ivPreview.setImageURI(uri);
                        Toast.makeText(this, "Image selected!", Toast.LENGTH_SHORT).show();
                    }
                });

        btnUploadImage.setOnClickListener(v -> galleryLauncher.launch("image/*"));

        btnAnalyze.setOnClickListener(v -> {
            String foodName = etFoodName.getText().toString().trim();
            String quantity = etQuantity.getText().toString().trim();

            if (foodName.isEmpty() || quantity.isEmpty()) {
                Toast.makeText(this, "Please enter both food name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            String query = quantity + " " + foodName;
            analyzeFood(query);
        });
    }

    private void analyzeFood(String query) {
        String url = API_URL + query;
        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray items = response.getJSONArray("items");
                        if (items.length() > 0) {
                            JSONObject obj = items.getJSONObject(0);

                            String name = obj.getString("name");
                            double calories = obj.optDouble("calories", 0);
                            double protein = obj.optDouble("protein_g", 0);
                            double fat = obj.optDouble("fat_total_g", 0);
                            double carbs = obj.optDouble("carbohydrates_total_g", 0);

                            saveToFirebase(name, calories, protein, fat, carbs);

                            String info = "🍽️ " + name +
                                    "\nCalories: " + calories + " kcal" +
                                    "\nProtein: " + protein + " g" +
                                    "\nFat: " + fat + " g" +
                                    "\nCarbs: " + carbs + " g";

                            Toast.makeText(this, info, Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(this, "No data found for this food.", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Toast.makeText(this, "Parse error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Error fetching data", Toast.LENGTH_SHORT).show()) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("X-Api-Key", API_KEY);
                return headers;
            }
        };

        queue.add(request);
    }

    private void saveToFirebase(String name, double calories, double protein, double fat, double carbs) {
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Not logged in", Toast.LENGTH_SHORT).show();
            return;
        }

        String uid = auth.getCurrentUser().getUid();
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

        DatabaseReference mealRef = dbRef.child(uid).child("meals").child(date).push();

        Map<String, Object> mealData = new HashMap<>();
        mealData.put("name", name);
        mealData.put("calories", calories);
        mealData.put("protein", protein);
        mealData.put("fat", fat);
        mealData.put("carbs", carbs);
        mealData.put("timestamp", time);

        mealRef.setValue(mealData)
                .addOnSuccessListener(aVoid -> {
                    if (selectedImageUri != null) {
                        uploadImage(mealRef.getKey());
                    } else {
                        Toast.makeText(this, "Saved successfully!", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to save data", Toast.LENGTH_SHORT).show());
    }

    private void uploadImage(String mealId) {
        if (selectedImageUri == null || auth.getCurrentUser() == null) return;

        String uid = auth.getCurrentUser().getUid();
        StorageReference imgRef = storageRef.child(uid + "/" + mealId + ".jpg");

        imgRef.putFile(selectedImageUri)
                .addOnSuccessListener(taskSnapshot -> imgRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    dbRef.child(uid).child("meals")
                            .child(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()))
                            .child(mealId)
                            .child("imageUrl")
                            .setValue(uri.toString());
                    Toast.makeText(this, "Image uploaded!", Toast.LENGTH_SHORT).show();
                }))
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Image upload failed", Toast.LENGTH_SHORT).show());
    }
}
