package com.example.nutrisnap.api;

import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Query;

public interface NutritionApiService {

    // 🔹 GET request to Spoonacular's endpoint
    // Example: https://api.spoonacular.com/food/ingredients/search?query=apple&apiKey=YOUR_API_KEY
    @Headers({
            "Content-Type: application/json"
    })
    @GET("food/ingredients/search")
    Call<HashMap<String, Object>> searchFood(
            @Query("query") String query,
            @Query("number") int number,
            @Query("apiKey") String apiKey
    );

    // 🔹 Another endpoint to get detailed nutrition info by ID
    // Example: https://api.spoonacular.com/food/ingredients/{id}/information?amount=100&unit=grams&apiKey=YOUR_API_KEY
    @GET("food/ingredients/{id}/information")
    Call<HashMap<String, Object>> getFoodNutrition(
            @retrofit2.http.Path("id") int id,
            @Query("amount") double amount,
            @Query("unit") String unit,
            @Query("apiKey") String apiKey
    );

    // 🔹 Factory method for Retrofit instance
    static NutritionApiService create() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.spoonacular.com/") // ✅ Base URL for Spoonacular
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        return retrofit.create(NutritionApiService.class);
    }
}
