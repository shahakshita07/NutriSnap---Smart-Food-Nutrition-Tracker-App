package com.example.nutrisnap;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.ViewHolder> {
    private final List<FoodItem> foodList;

    public FoodAdapter(List<FoodItem> foodList) {
        this.foodList = foodList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_food_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        FoodItem food = foodList.get(position);

        holder.name.setText(food.getName() != null ? food.getName() : "Unnamed");
        holder.quantity.setText((food.getQuantity() != null && !food.getQuantity().isEmpty())
                ? food.getQuantity()
                : "—");
        holder.calories.setText(String.format("%.0f kcal", food.getCalories()));
    }

    @Override
    public int getItemCount() {
        return foodList != null ? foodList.size() : 0;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, quantity, calories;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.foodName);
            quantity = itemView.findViewById(R.id.foodQuantity);
            calories = itemView.findViewById(R.id.foodCalories);
        }
    }
}
