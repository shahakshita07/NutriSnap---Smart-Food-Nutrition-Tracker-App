package com.example.nutrisnap;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;

public class SharedViewModel extends ViewModel {

    private final MutableLiveData<List<FoodItem>> foodList = new MutableLiveData<>(new ArrayList<>());

    // Nutritional data LiveData
    private final MutableLiveData<String> foodNameLive = new MutableLiveData<>();
    private final MutableLiveData<Double> caloriesLive = new MutableLiveData<>();
    private final MutableLiveData<Double> proteinLive = new MutableLiveData<>();
    private final MutableLiveData<Double> carbsLive = new MutableLiveData<>();
    private final MutableLiveData<Double> fatLive = new MutableLiveData<>();

    public LiveData<List<FoodItem>> getFoodList() {
        return foodList;
    }

    public void addFood(FoodItem foodItem) {
        List<FoodItem> currentList = foodList.getValue();
        if (currentList != null) {
            currentList.add(foodItem);
            foodList.setValue(new ArrayList<>(currentList));
        }
    }

    public void clearFoods() {
        foodList.setValue(new ArrayList<>());
    }

    // ✅ New method to store nutrition data (fixes your error)
    public void setNutritionData(String foodName, double calories, double protein, double carbs, double fat) {
        foodNameLive.setValue(foodName);
        caloriesLive.setValue(calories);
        proteinLive.setValue(protein);
        carbsLive.setValue(carbs);
        fatLive.setValue(fat);
    }

    // Getters for observing in ResultsFragment if needed
    public LiveData<String> getFoodName() { return foodNameLive; }
    public LiveData<Double> getCalories() { return caloriesLive; }
    public LiveData<Double> getProtein() { return proteinLive; }
    public LiveData<Double> getCarbs() { return carbsLive; }
    public LiveData<Double> getFat() { return fatLive; }
}
