package com.example.nutrisnap.fragments;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.nutrisnap.FoodAdapter;
import com.example.nutrisnap.FoodItem;
import com.example.nutrisnap.R;
import com.example.nutrisnap.SharedViewModel;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DashboardFragment extends Fragment {

    private PieChart pieChart;
    private RecyclerView recyclerView;
    private TextView dateView, totalCaloriesView;
    private FoodAdapter adapter;
    private SharedViewModel sharedViewModel;
    private final List<FoodItem> foodList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_dashboard_fragment, container, false);

        pieChart = view.findViewById(R.id.pieChart);
        recyclerView = view.findViewById(R.id.recyclerViewFood);
        dateView = view.findViewById(R.id.txtDate);
        totalCaloriesView = view.findViewById(R.id.txtTotalCalories);
        FloatingActionButton fab = view.findViewById(R.id.fabAddFood);

        // ViewModel connection (shared with ScanFragment)
        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);

        // Show today’s date
        String currentDate = new SimpleDateFormat("EEEE, MMM dd", Locale.getDefault()).format(new Date());
        dateView.setText(currentDate);

        // Open date picker on click
        dateView.setOnClickListener(v -> showDatePicker());

        // Recycler setup
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new FoodAdapter(foodList);
        recyclerView.setAdapter(adapter);

        // Chart setup
        setupPieChart();

        // Observe shared ViewModel for updates
        sharedViewModel.getFoodList().observe(getViewLifecycleOwner(), list -> {
            foodList.clear();
            foodList.addAll(list);
            adapter.notifyDataSetChanged();
            updatePieChart();
        });

        // Floating button opens ScanFragment
        fab.setOnClickListener(v -> getParentFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, new ScanFragment())
                .addToBackStack(null)
                .commit());

        return view;
    }

    private void setupPieChart() {
        pieChart.setUsePercentValues(false);
        pieChart.getDescription().setEnabled(false);
        pieChart.setHoleRadius(45f);
        pieChart.setTransparentCircleRadius(50f);
        pieChart.setEntryLabelTextSize(12f);
        pieChart.setEntryLabelColor(Color.BLACK);
        pieChart.setCenterText("Calories Breakdown");
        pieChart.setCenterTextSize(14f);
        pieChart.setCenterTextColor(Color.DKGRAY);

        Legend legend = pieChart.getLegend();
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        legend.setWordWrapEnabled(true);
        legend.setTextSize(12f);

        updatePieChart();
    }

    private void updatePieChart() {
        ArrayList<PieEntry> entries = new ArrayList<>();
        float totalCalories = 0f;

        for (FoodItem item : foodList) {
            if (item.getCalories() > 0) {
                entries.add(new PieEntry((float) item.getCalories(), item.getName()));
                totalCalories += item.getCalories();
            }
        }

        // If no data, show placeholder entry
        if (entries.isEmpty()) {
            entries.add(new PieEntry(1f, "No data"));
        }

        PieDataSet dataSet = new PieDataSet(entries, "Calories per Food");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        dataSet.setSliceSpace(3f);
        dataSet.setValueTextSize(12f);
        dataSet.setValueTextColor(Color.BLACK);

        PieData data = new PieData(dataSet);
        pieChart.setData(data);

        if (totalCaloriesView != null)
            totalCaloriesView.setText("Total Calories: " + (int) totalCalories + " kcal");

        pieChart.setCenterText(totalCalories > 0 ? "Total: " + (int) totalCalories + " kcal" : "No Entries");
        pieChart.animateY(1000);
        pieChart.invalidate();
    }

    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        DatePickerDialog dialog = new DatePickerDialog(requireContext(),
                (DatePicker view, int year, int month, int dayOfMonth) -> {
                    calendar.set(year, month, dayOfMonth);
                    String selectedDate = new SimpleDateFormat("EEEE, MMM dd", Locale.getDefault())
                            .format(calendar.getTime());
                    dateView.setText(selectedDate);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));
        dialog.show();
    }
}
